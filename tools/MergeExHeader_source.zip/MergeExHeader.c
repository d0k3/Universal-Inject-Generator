#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

int freadwhole(char *name, uint8_t **buf) {
	FILE *fp = 0;
	size_t fl = 0;
	uint8_t *fc = 0;
	fp = fopen(name, "rb");
	if (!fp) return 0;
	fseek(fp, 0, SEEK_END);
	fl = ftell(fp);
	fseek(fp, 0, SEEK_SET);
	fc = (uint8_t*)malloc(fl);
	fread(fc, 1, fl, fp);
	fclose(fp);
	*buf = fc;
	return fl;
}

int main(int argc, char** argv) {
	FILE *fout=0; //Output Exheader file.
	uint8_t *fcnew=0,*fcold=0;
	char fno[256] = {0,}; //Content: New (also for output), Old. Output name
	size_t flnew=0, flold=0;
	int i = 0; //iterator
	
	printf("[DBG:]argc=%d\n",argc);
	for (i=0;i<argc;i++) printf("[DBG:]argv[%d]=%s\n",i,argv[i]);
	
	printf("[INFO]Exheader Merge for APP injection.\n");
	if (argc < 3) {
		printf("[SYS:]Please pass enough arguments!\n");
		printf("[HELP]Arguments: <New> <Old>[ <Output>]\n");
		printf("[HELP]  New is the new APP to be injected,    for example, FBI.\n");
		printf("[HELP]  Old is the old APP to be overwritten, for example, H&S.\n");
		printf("[HELP]Please always pass a valid file in order, program won't check.\n");
		exit(0);
	}
	
	//Loading both files.
	printf("[INFO]Loading files. New=%s, Old=%s....", argv[1], argv[2]);
	flold = freadwhole(argv[2], &fcold);
	flnew = freadwhole(argv[1], &fcnew);
	if ((!fcold)||(!fcnew)) {
		printf("FAIL. File not found!\n");
		exit(0);
	}
	if (flold != flnew) {
		printf("FAIL. File size mismatch.\n");
		exit(0);
	}
	printf("DONE.\n");
	
	//All we do around those patching - Overwrite the original New File Content.
	//0x0000+0x08. Appliaction Title
	printf("[INFO]Patch #1: 0x0000+0x08..");
	memcpy(fcnew+0x0000, fcold+0x0000, 0x08);
	printf("DONE.\n");
	
	//0x000C+0x04. Remaster Version, and Flag.
	printf("[INFO]Patch #2: 0x000C+0x04..");
	memcpy(fcnew+0x000C, fcold+0x000C, 0x04);
	printf("DONE.\n");
	
	//0x01C8+0x08. Jump ID.
	printf("[INFO]Patch #3: 0x01C8+0x08..");
	memcpy(fcnew+0x01C8, fcold+0x01C8, 0x08);
	printf("DONE.\n");
	
	//0x0200+0x08. ACI Program ID
	printf("[INFO]Patch #4: 0x0200+0x08..");
	memcpy(fcnew+0x0200, fcold+0x0200, 0x08);
	printf("DONE.\n");
	
	//0x0248+0x01. ACI FS access Info. Merge.
	printf("[INFO]Merge #5: 0x0248+0x01..");
	fcnew[0x0248] = fcnew[0x0248] | fcold[0x0248];
	printf("DONE.\n");
	
	//0x0600+0x08. ACI2 Program ID
	printf("[INFO]Patch #6: 0x0600+0x08..");
	memcpy(fcnew+0x0600, fcold+0x0600, 0x08);
	printf("DONE.\n");
	
	//0x0648+0x01. ACI FS access Info. Merge.
	printf("[INFO]Merge #7: 0x0648+0x01..");
	fcnew[0x0648] = fcnew[0x0648] | fcold[0x0648];
	printf("DONE.\n");
	
	//All Patched. Write the file.
	if (argc >= 4) {
		fout = fopen(argv[3], "wb+");
		printf("[INFO]Saving file to %s..", argv[3]);
	} else {
		memset(fno, 0, 256);
		snprintf(fno, 256, "%s.update", argv[2]);
		fout = fopen(fno, "wb+");
		printf("[INFO]Saving file to %s..", fno);
	}
	if (!fout) {
		printf("FAIL. Write file failed. Check your access!\n");
		exit(0);
	}
	fwrite(fcnew, 1, flnew, fout);
	fclose(fout);
	free(fcnew); free(fcold);
	printf("DONE.\n");
	
	printf("[INFO]All done. Program would exit.\n");
	exit(0);
}